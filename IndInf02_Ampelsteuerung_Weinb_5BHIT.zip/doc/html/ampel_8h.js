var ampel_8h =
[
    [ "ampelparameter", "structampelparameter.html", "structampelparameter" ],
    [ "ampelevent", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29", [
      [ "FAHREN", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29a0024f078d68f31a6ff79a0fb50298c99", null ],
      [ "HALT", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29aa2fd6bbb0c07e28e835ba595e64df78c", null ],
      [ "VORBEREITUNG_FAHREN", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29a375c69e6ffb4e55da951529d18ed300f", null ],
      [ "VORBEREITUNG_HALT", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29a77b38a2aea6462065244d883568ec1df", null ],
      [ "ACHTUNG", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29a76c795fcce74acf303dce48f7e484dc3", null ],
      [ "FALSE", "ampel_8h.html#a81b8396a1636de3e1e604ce4935e2f29aa1e095cc966dbecf6a0d8aad75348d1a", null ]
    ] ],
    [ "ampelzustand", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012", [
      [ "ROT", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012a59b0dd0d260e722b287c37c6099128b8", null ],
      [ "ROT_GELB", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012a72b89ac084d8a50e8ad6661d2ade7c29", null ],
      [ "GRUEN", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012a27afd8640ceaa64a79970c6f81af6bc2", null ],
      [ "GRUEN_BLINKEN", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012afbc853336941e239fb96f393809fa9df", null ],
      [ "GELB", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012a954d5ef677a329a041026b662c035456", null ],
      [ "GELB_BLINKEN", "ampel_8h.html#a5f4305c91042b570d5d94e83ce6b8012aed1d0e4846f0e252b7bbf039a30878b1", null ]
    ] ],
    [ "ampel", "ampel_8h.html#a591d34377b80002f63ff21438c8b7207", null ]
];