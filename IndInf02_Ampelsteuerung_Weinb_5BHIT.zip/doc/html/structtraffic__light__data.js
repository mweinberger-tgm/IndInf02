var structtraffic__light__data =
[
    [ "event", "structtraffic__light__data.html#a2181ff2fe01d7e779b7c394edfe2fdc7", null ],
    [ "state", "structtraffic__light__data.html#a68153484e80b8468dba92d3d50754ef6", null ]
];