var traffic__light_8h =
[
    [ "traffic_light_data", "structtraffic__light__data.html", "structtraffic__light__data" ],
    [ "traffic_event", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31", [
      [ "STOP", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31a679ee5320d66c8322e310daeb2ee99b8", null ],
      [ "PREPARE_GO", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31a916efa94b31a1ba74c3de2a031720bd5", null ],
      [ "GO", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31a50d8e53aac4e002d0fd296c5033ce985", null ],
      [ "PREPARE_CAUTION", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31a247701d0eaa3fe76f92ee2261c6a8b0a", null ],
      [ "CAUTION", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31ad2d01f5e0786e0ffc717753f224a0127", null ],
      [ "FAULT", "traffic__light_8h.html#a5dd9ab2cfb1c1c4ad4dab0dc5fd1fb31ab7f3a434cd7c576917ad58613673c571", null ]
    ] ],
    [ "traffic_state", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811", [
      [ "RED", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811af80f9a890089d211842d59625e561f88", null ],
      [ "RED_YELLOW", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811a0ba403e582f13ac4452785af422f1309", null ],
      [ "GREEN", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811aa60bd322f93178d68184e30e162571ca", null ],
      [ "GREEN_BLINK", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811af1f1054b00dd7aaa9267c09c6ca7ca3b", null ],
      [ "YELLOW", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811ae735a848bf82163a19236ead1c3ef2d2", null ],
      [ "YELLOW_BLINK", "traffic__light_8h.html#ae1939dd3965083c1b787f49b04617811a27b5723934d5d16be138d8668e88399b", null ]
    ] ],
    [ "traffic_light_control", "traffic__light_8h.html#a4576125fe880e2fb11525567fb8976be", null ]
];