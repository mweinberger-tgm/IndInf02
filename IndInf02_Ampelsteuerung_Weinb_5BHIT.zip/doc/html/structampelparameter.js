var structampelparameter =
[
    [ "event", "structampelparameter.html#ad70553c5639d1dbd1db238ba0ede8fc2", null ],
    [ "zustand", "structampelparameter.html#aa3e849a47e5e680b0f4fe0d2d4727126", null ]
];