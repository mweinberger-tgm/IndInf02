var group___s_t_m32_f3xx___system___private___defines =
[
    [ "HSE_VALUE", "group___s_t_m32_f3xx___system___private___defines.html#gaeafcff4f57440c60e64812dddd13e7cb", null ],
    [ "HSI_VALUE", "group___s_t_m32_f3xx___system___private___defines.html#gaaa8c76e274d0f6dd2cefb5d0b17fbc37", null ],
    [ "VECT_TAB_OFFSET", "group___s_t_m32_f3xx___system___private___defines.html#ga40e1495541cbb4acbe3f1819bd87a9fe", null ]
];